from tkinter import *
import string
import random
from PIL import Image, ImageTk

class PasswordGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("Password Generator")
        self.root.geometry('570x500')
        self.root.resizable(False, False)

        self.setup_variables()
        self.setup_ui()

    def setup_variables(self):
        self.choice = IntVar()

    def setup_ui(self):
        # Fonts and colors
        Font = ('calibri', 17, 'bold')
        bg_color = 'Navy'
        fg_color = 'white'

        # Image
        self.logo_image = Image.open('image/Capture.png')  # Update this path to your actual image file location
        self.logo_photo_image = ImageTk.PhotoImage(self.logo_image)
        imageLabel = Label(self.root, image=self.logo_photo_image)
        imageLabel.pack(pady=(10, 20))

        # Labels
        passwordLabel = Label(self.root, text='Password Generator', font=('times new roman', 25, 'bold'), bg=bg_color, fg=fg_color)
        passwordLabel.pack(fill='x')

        # Level selection
        frame = Frame(self.root)
        frame.pack(pady=(10, 0), fill='x')

        levelLabel = Label(frame, text="Level", font=Font, bg=bg_color, fg=fg_color)
        levelLabel.pack(side='left', padx=(10, 0))

        Radiobutton(frame, text='Weak', value=1, variable=self.choice, font=Font).pack(side='left', padx=(50, 10))
        Radiobutton(frame, text='Medium', value=2, variable=self.choice, font=Font).pack(side='left', padx=(10, 10))
        Radiobutton(frame, text='Strong', value=3, variable=self.choice, font=Font).pack(side='left', padx=(10, 10))

        # Password Length
        length_frame = Frame(self.root)
        length_frame.pack(pady=(10, 0), fill='x')

        lengthLabel = Label(length_frame, text='Password Length', font=Font, bg=bg_color, fg=fg_color)
        lengthLabel.pack(side='left', padx=(10, 0))

        self.length_Box = Spinbox(length_frame, from_=5, to=18, width=5, font=Font)
        self.length_Box.pack(side='left', padx=(50, 10))

        # Password Entry and Buttons
        entry_frame = Frame(self.root)
        entry_frame.pack(pady=(10, 0), fill='x')

        self.passwordField = Entry(entry_frame, font=Font)
        self.passwordField.pack(side='left', expand=True, fill='x', padx=(10, 5))

        generateButton = Button(entry_frame, text='Generate', font=Font, command=self.generator, bg=bg_color, fg='white')
        generateButton.pack(side='left', padx=(5, 10))

        copyButton = Button(entry_frame, text='Copy', font=Font, command=self.copy_to_clipboard, bg=bg_color, fg='white')
        copyButton.pack(side='left', padx=(5, 10))

        # Footer
        footerLabel = Label(self.root, text='Done By Abdallah Kaadan', font=Font, bg=bg_color, fg=fg_color)
        footerLabel.pack(side='bottom', fill='x')

    def generator(self):
        all_chars = {
            1: string.ascii_lowercase,
            2: string.ascii_lowercase + string.ascii_uppercase,
            3: string.ascii_lowercase + string.ascii_uppercase + string.digits + string.punctuation
        }
        
        choice_level = self.choice.get()
        password_chars = all_chars.get(choice_level, None)
        
        if password_chars is None:
            self.passwordField.delete(0, END)
            self.passwordField.insert(0, 'Select password strength')
            return
        
        try:
            password_length = int(self.length_Box.get())
            if password_length < 5 or password_length > 18:
                raise ValueError("Invalid length")
            password = ''.join(random.choice(password_chars) for _ in range(password_length))
            self.passwordField.delete(0, END)
            self.passwordField.insert(0, password)
        except ValueError as e:
            self.passwordField.delete(0, END)
            self.passwordField.insert(0, str(e))

    def copy_to_clipboard(self):
        random_password = self.passwordField.get()
        if random_password:
            self.root.clipboard_clear()
            self.root.clipboard_append(random_password)

def main():
    root = Tk()
    app = PasswordGenerator(root)
    root.mainloop()

if __name__ == "__main__":
    main()
